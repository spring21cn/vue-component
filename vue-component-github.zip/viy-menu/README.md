前端项目基础框架

## 功能：
- 登录
- 基本菜单

```bash
# 克隆项目
git clone 

# 安装依赖
npm install

# 启动服务
npm start

# 编译
npm run build
```